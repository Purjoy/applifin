<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
        <?php foreach($errors->all() as $error): ?>
        <?php echo e($error); ?>

        <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Editer un commentaire</div>
                    <div class="panel-body">

                    <?php if(Auth::check()
                    && (Auth::user()->id == $comment->user_id
                    || Auth::user()->isAdmin)): ?>

                        <?php echo Form::model($comment,
                            array(
                            'route' => array('comment.update', $comment->id),
                            'method' => 'PUT'
                            )); ?>

                            <div class="form-group">
                                <?php echo Form::label('Comment', 'Modifier un commentaire'); ?>

                                <?php echo Form::textarea('comment', old('comment'), 
                                    ['class' => 'form-control']); ?>

                            </div>
                        
                    </div>
                    <div class="panel-footer">
                        <?php echo Form::submit('Publier le commentaire',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>


                        <?php else: ?>
                        
                        <p>Vous n'avez pas les droits nécessaires</p>

                        <?php endif; ?>

                        <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>