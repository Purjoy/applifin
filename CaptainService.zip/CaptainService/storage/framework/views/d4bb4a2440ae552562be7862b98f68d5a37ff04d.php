<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row bloc-index">
        <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php foreach($list as $post): ?>
            <div class="well">
                <?php echo e($post->message); ?>

            </div>


    <?php endforeach; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>