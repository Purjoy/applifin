<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row bloc-index">
        <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-xs-6">
            <div class="dropdown dropdown-margin">
                <button class="btn btn-default dropdown-toggle btn-trie" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Catégorie
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu categorie-menu menu-trie" aria-labelledby="dropdownMenu1">
                <li><a href="<?php echo e(route('post.tag', '1')); ?>">Aide ménagère</a></li>
                <li><a href="<?php echo e(route('post.tag', '2')); ?>">Jardinage</a></li>
                <li><a href="<?php echo e(route('post.tag', '3')); ?>">Babysitting</a></li>
                <li><a href="<?php echo e(route('post.tag', '4')); ?>">Aide scolaire</a></li>
                <li><a href="<?php echo e(route('post.tag', '5')); ?>">Informatique</a></li>
                <li><a href="<?php echo e(route('post.tag', '6')); ?>">Bricolage</a></li>
                <li><a href="<?php echo e(route('post.tag', '7')); ?>">Autre</a></li>
            </ul>
            </div>
        </div>
        <div class="col-xs-6">
            <div class="dropdown">
                <button class="btn btn-default dropdown-toggle btn-trie" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Prix
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu categorie-menu menu-trie" aria-labelledby="dropdownMenu1">
                <li><a href="<?php echo e(route('post.prix', '8')); ?>">1€ - 10€</a></li>
                <li><a href="<?php echo e(route('post.prix', '9')); ?>">11€ - 20€</a></li>
                <li><a href="<?php echo e(route('post.prix', '10')); ?>">21€ - 30€</a></li>
                <li><a href="<?php echo e(route('post.prix', '11')); ?>">31€ - 40€</a></li>
                <li><a href="<?php echo e(route('post.prix', '12')); ?>">41€ - 50€</a></li>
            </ul>
            </div>
        </div>
        <?php foreach($posts as $post): ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                <a href="<?php echo e(route('post.show', $post->id)); ?>">
                    <?php if($post->img == '1'): ?>
                    <img src="<?php echo e(asset("img/aide-menagere.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '2'): ?>
                    <img src="<?php echo e(asset("img/jardinage.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '3'): ?>
                    <img src="<?php echo e(asset("img/babysitting.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '4'): ?>
                    <img src="<?php echo e(asset("img/aide-scolaire.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '5'): ?>
                    <img src="<?php echo e(asset("img/informatique.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '6'): ?>
                    <img src="<?php echo e(asset("img/bricolage.png")); ?>" alt="" class="img-responsive image">
                    <?php else: ?>
                    <img src="<?php echo e(asset("img/autres.png")); ?>" alt="" class="img-responsive image">
                    <?php endif; ?>
                    </a>
                </div>

                <div class="panel-header">
                        <a class="titre" href="<?php echo e(route('post.show', $post->id)); ?>"><b><?php echo e($post->title); ?></b></a>
                        <br>
                        <p class="date"><?php echo e($post->created_at); ?></p>
                        <br>
                </div>
                <div class="panel-bas">
                    <div class="row">
                    <div class="col-xs-4">
                        <span class="lieu"><b><?php echo e($post->lieu); ?></b></span>
                    </div>
                    <div class="col-xs-4">
                        <span class="prix">
                        <b><?php if($post->prix == '8'): ?>
                            <span class="prix">1€ - 10€</span>
                            <?php elseif($post->prix == '9'): ?>
                            <span class="prix">11€ - 20€</span>
                            <?php elseif($post->prix == '10'): ?>
                            <span class="prix">21€ - 30€</span>
                            <?php elseif($post->prix == '11'): ?>
                            <span class="prix">31€ - 40€</span>
                            <?php else: ?>
                            <span class="prix">41€ - 50€</span>
                            <?php endif; ?></b>
                        </span>
                    </div>
                    <div class="col-xs-4">
                        <span class="tag">
                        <b><?php if($post->img == '1'): ?>
                            #aideménagère
                            <?php elseif($post->img == '2'): ?>
                            #jardinage
                            <?php elseif($post->img == '3'): ?>
                            #babysitting
                            <?php elseif($post->img == '4'): ?>
                            #aidescolaire
                            <?php elseif($post->img == '5'): ?>
                            #informatique
                            <?php elseif($post->img == '6'): ?>
                            #bricolage
                            <?php else: ?>
                            #autre
                            <?php endif; ?></b>
                        </span>
                        </div>
                    </div>    
                    </div> 
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>