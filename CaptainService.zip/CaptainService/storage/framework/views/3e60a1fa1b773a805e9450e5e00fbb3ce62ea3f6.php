<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align: center;" ><h3><?php echo e($post->title); ?></h3>Créer le : <?php echo e($post->created_at); ?></div>

                <div class="panel-body">
                    <?php echo e($post->content); ?>

                </div>

                <div class="panel-footer" style="text-align: center;">
                <?php if(Auth::check()
                && (Auth::user()->id == $post->user_id
                || Auth::user()->isAdmin)): ?>

                    <?php echo Form::model($post, array(
                        'route' => array('post.destroy', $post->id),
                        'method' => 'DELETE')); ?>


                    <?php echo Form::submit('Supprimer', ['class' => 'btn btn-default']); ?>


                    
                    
                
                    <a class="btn btn-default" href="<?php echo e(route('post.edit', $post->id)); ?>">Modifier l'article</a>
                
                <?php endif; ?>

                    <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>

                    <?php echo Form::close(); ?>

                </div>
                <div class="panel-body">
                    <h3>Commentaires</h3>

                    <div class="panel-body">
                        <?php echo Form::open(array(
                            'route' => 'comment.store',
                            'method' => 'POST'
                            )); ?>

                            <?php echo Form::hidden('post_id', $post->id, ['class'=>'form-control']); ?>


                            <div class="form-group">
                                <?php echo Form::label('Comment', 'Écrire un commentaire'); ?>

                                <?php echo Form::textarea('comment', '', 
                                    ['class' => 'form-control']); ?>

                            </div>
                        
                        <?php echo Form::submit('Publier le commentaire',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>


                        <br>
                    </div>

                    <?php foreach($post->comments as $comment): ?>
                        <p>
                            <strong><?php echo e($comment->user->name); ?></strong>
                            <br>
                            <?php echo e($comment->comment); ?>

                        </p>

                        <?php if(Auth::check()
                        && (Auth::user()->id == $comment->user_id
                        || Auth::user()->isAdmin)): ?>

                            <?php echo Form::model($comment, array(
                                'route' => array('comment.destroy', $comment->id),
                                'method' => 'DELETE')); ?>


                            <?php echo Form::submit('Supprimer', ['class' => 'btn btn-default']); ?>


                            
                            
                        
                            <a class="btn btn-default" href="<?php echo e(route('comment.edit', $comment->id)); ?>">Modifier le commentaire</a>
                        
                        <?php endif; ?>

                        <?php echo Form::close(); ?>


                        <br>

                    <?php endforeach; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>