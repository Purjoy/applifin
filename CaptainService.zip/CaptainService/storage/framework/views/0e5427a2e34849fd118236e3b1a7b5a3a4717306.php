<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
        <?php foreach($errors->all() as $error): ?>
        <?php echo e($error); ?>

        <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Editer un article</div>
                    <div class="panel-body">

                    <?php if(Auth::check()
                    && (Auth::user()->id == $post->user_id
                    || Auth::user()->isAdmin)): ?>

                        <?php echo Form::model($post,
                            array(
                            'route' => array('post.update', $post->id),
                            'method' => 'PUT'
                            )); ?>

                            <div class="form-group">
                                <?php echo Form::label('title', 'Titre'); ?>

                                <?php echo Form::text('title', old('title'), 
                                    ['class' => 'form-control',
                                    'placeholder' => ''
                                    ]); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('img', 'Type de service : '); ?>

                                <?php echo Form::select('img', array('1' => 'Aide ménagère', '2' => 'Jardinnage', '3' => 'Babysitting', '4' => 'Aide scolaire', '5' => 'Informatique', '6' => 'Bricolage', '7' => 'Autre'),
                                    ['class' => 'form-control'
                                    ]);; ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('content', 'Contenu'); ?>

                                <?php echo Form::textarea('content', old('content'), 
                                    ['class' => 'form-control',
                                    'placeholder' => ''
                                    ]); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('prix', 'Prix'); ?>

                                <?php echo Form::text('prix', old('prix'), 
                                    ['class' => 'form-control',
                                    'placeholder' => ''
                                    ]); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('lieu', 'Ville'); ?>

                                <?php echo Form::text('lieu', old('lieu'), 
                                    ['class' => 'form-control',
                                    'placeholder' => ''
                                    ]); ?>

                            </div>
                        
                    </div>
                    <div class="panel-footer">
                        <?php echo Form::submit('Publier l\'article',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>


                        <?php else: ?>
                        
                        <p>Vous n'avez pas les droits nécessaires</p>

                        <?php endif; ?>

                        <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>