 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
        <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php foreach($list as $post): ?>
                <div class="col-md-10 col-md-offset-1">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a href="<?php echo e(route('post.show', $post->id)); ?>"><?php echo e($post->title); ?></a> | Créer le : <?php echo e($post->created_at); ?>

                        </div>

                        <div class="panel-body">
                            <?php echo e($post->content); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php echo $list->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>