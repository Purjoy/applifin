<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Ajouter un article</div>
                    <div class="panel-body">
                        <?php echo Form::open(array(
                            'route' => 'post.store',
                            'method' => 'POST'
                            )); ?>

                            <div class="form-group">
                                <?php echo Form::label('title', 'Titre'); ?>

                                <?php echo Form::text('title', '', 
                                    ['class' => 'form-control',
                                    'placeholder' => 'Mon titre'
                                    ]); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('content', 'Contenu'); ?>

                                <?php echo Form::textarea('content', '', 
                                    ['class' => 'form-control',
                                    'placeholder' => 'Contenu'
                                    ]); ?>

                            </div>
                        
                    </div>
                    <div class="panel-footer">
                        <?php echo Form::submit('Publier l\'article',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>

                        <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>