<?php if($success = Session::get('success')): ?>
	<div class="alert alert-success">
		<?php echo e($success); ?>

	</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
	<?php foreach($errors->all() as $error): ?>
	<?php echo e($error); ?>

	<?php endforeach; ?>
</div>
<?php endif; ?>