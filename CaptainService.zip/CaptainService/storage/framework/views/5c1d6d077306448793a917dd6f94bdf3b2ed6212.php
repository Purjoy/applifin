<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php foreach($errors->all() as $error): ?>
                        <?php echo e($error); ?>

                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Modifier votre Profil</div>
                    <div class="panel-body">


                            <?php echo Form::model($user,
                                array(
                                'route' => array('user.update', $user->id),
                                'method' => 'PUT'
                                )); ?>


                            <div class="form-group">
                                <?php echo Form::label('name', 'Nom'); ?>

                                <?php echo Form::text('name', old('Nom'),
                                    ['class' => 'form-control',
                                    'placeholder' => 'Nom'
                                    ]); ?>

                            </div>

                        <div class="form-group">
                            <?php echo Form::label('email', 'E-mail'); ?>

                            <?php echo Form::email('email', old('E-mail'),
                                ['class' => 'form-control',
                                'placeholder' => 'E-mail'
                                ]); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('password', 'Mot de passe'); ?>

                            <?php echo Form::password('password', old('Mot de passe'),
                                ['class' => 'form-control',
                                'placeholder' => 'Mot de passe'
                                ]); ?>

                        </div>

                    </div>
                    <div class="panel-footer">
                        <?php echo Form::submit('Modifier',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>



                        <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>