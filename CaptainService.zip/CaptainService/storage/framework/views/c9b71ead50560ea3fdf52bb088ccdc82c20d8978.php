<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Ajouter un article</div>
                    <div class="panel-body">
                        <?php echo Form::open(array(
                            'route' => 'post.store',
                            'method' => 'POST'
                            )); ?>

                            <div class="form-group">
                                <?php echo Form::label('title', 'Titre'); ?>

                                <?php echo Form::text('title', '', 
                                    ['class' => 'form-control',
                                    ]); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('img', 'Type de service : '); ?>

                                <?php echo Form::select('img', array('1' => 'Aide ménagère', '2' => 'Jardinnage', '3' => 'Babysitting', '4' => 'Aide scolaire', '5' => 'Informatique', '6' => 'Bricolage', '7' => 'Autre'),
                                    ['class' => 'form-control'
                                    ]);; ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('content', 'Description'); ?>

                                <?php echo Form::textarea('content', '', 
                                    ['class' => 'form-control',
                                    'placeholder' => 'Quelle est votre demande ?'
                                    ]); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('prix', 'Tranche de prix : '); ?>

                                <?php echo Form::select('prix', array('8' => '1€ - 10€', '9' => '11€ - 20€', '10' => '21€ - 30€', '11' => '31€ - 40€', '12' => '41€ - 50€'),
                                    ['class' => 'form-control'
                                    ]);; ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('lieu', 'Ville'); ?>

                                <?php echo Form::text('lieu', '', 
                                    ['class' => 'form-control',
                                    'placeholder' => ''
                                    ]); ?>

                            </div>
                        
                    </div>
                    <div class="panel-footer">
                        <?php echo Form::submit('Publier l\'article',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>

                        <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>