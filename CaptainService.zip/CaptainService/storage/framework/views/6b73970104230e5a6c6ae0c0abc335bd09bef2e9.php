<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align: center;" ><h3><?php echo e($bap->name); ?></h3>Créer le : <?php echo e($bap->created_at); ?></div>

                <div class="panel-body">
                    <h5>Commanditaire</h5>
                    <p>
                    <strong>Nom et Prénom:</strong> <?php echo e($bap->NomPrenomCHEF); ?> <br>
                    <strong>Fonction:</strong> <?php echo e($bap->fonctionCHEF); ?> <br>
                    <strong>Adresse Postale:</strong> <?php echo e($bap->adresseCHEF); ?> <br>
                    <strong>Email:</strong> <?php echo e($bap->emailCHEF); ?> <br>
                    <strong>Téléphone:</strong> <?php echo e($bap->telCHEF); ?>

                    </p>
                    <h5>Contact</h5>
                    <p>
                    <strong>Nom et Prénom:</strong> <?php echo e($bap->NomPrenomCON); ?> <br>
                    <strong>Fonction:</strong> <?php echo e($bap->fonctionCON); ?> <br>
                    <strong>Adresse Postale:</strong> <?php echo e($bap->adresseCON); ?> <br>
                    <strong>Email:</strong> <?php echo e($bap->emailCON); ?> <br>
                    <strong>Téléphone:</strong> <?php echo e($bap->telCON); ?>

                    </p>
                    <h5>Fiche d'identité</h5>
                    <p>
                    <strong>Raison sociale, activité ...:</strong> <?php echo e($bap->social); ?> <br>
                    <strong>Type de demande:</strong> <?php echo e($bap->type); ?> <br>
                    <strong>Raison de la demande:</strong> <?php echo e($bap->raison); ?> <br>
                    <strong>Contexte de la demande:</strong> <?php echo e($bap->contexte); ?> <br>
                    <strong>Objectifs de la demande:</strong> <?php echo e($bap->objectif); ?> <br>
                    <strong>Contraintes et infos supplémentaires:</strong> <?php echo e($bap->contraintes); ?> 
                    </p>

                    <h5><?php if($bap->accepted == 1): ?> 
                                Statut: Accepté
                            <?php elseif($bap->accepted == 2): ?>
                                Statut: Refusé
                            <?php elseif($bap->accepted == 0): ?>
                                Statut: En attente
                            <?php endif; ?>
                    </h5>
                    
                </div>

                <div class="panel-footer" style="text-align: center;">
                    <?php echo Form::model($bap,
                            array(
                            'route' => array('bap.update', $bap->id),
                            'method' => 'PUT'
                            )); ?>

                    <?php echo Form::select('accepted', [
                           '0' => 'En attente',
                           '1' => 'Accepter',
                           '2' => 'Refuser']
                        ); ?>

                    <?php echo Form::submit('Valider',
                            ['class' => 'btn btn-primary']); ?>


                    <?php echo Form::close(); ?>


                    <br>

                    <?php echo Form::model($bap, array(
                        'route' => array('bap.destroy', $bap->id),
                        'method' => 'DELETE')); ?>


                    <?php echo Form::submit('Supprimer', ['class' => 'btn btn-default']); ?>

                

                    <a class="btn btn-default" href="<?php echo e(route('bap.index')); ?>">Retour aux projet</a>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>