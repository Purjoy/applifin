<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Contactez-nous !</div>
                    <div class="panel-body">
                        <?php echo Form::open(array(
                            'route' => 'contact.store',
                            'method' => 'POST'
                            )); ?>

                            <div class="form-group">
                                <?php echo Form::label('name', 'Nom'); ?>

                                <?php echo Form::text('name', '', 
                                    ['class' => 'form-control']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('email', 'Email'); ?>

                                <?php echo Form::text('email', '', 
                                    ['class' => 'form-control']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('message', 'Message'); ?>

                                <?php echo Form::textarea('message', '', 
                                    ['class' => 'form-control']); ?>

                            </div>
                        
                    </div>
                    <div class="panel-footer">
                        <?php echo Form::submit('Envoyer le message',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>

                        <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour à l'accueil</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>