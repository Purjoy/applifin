<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row bloc-index">
        <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php foreach($posts as $post): ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                <a href="<?php echo e(route('post.show', $post->id)); ?>">
                    <?php if($post->img == '1'): ?>
                    <img src="<?php echo e(asset("img/aide-menagere.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '2'): ?>
                    <img src="<?php echo e(asset("img/jardinage.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '3'): ?>
                    <img src="<?php echo e(asset("img/babysitting.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '4'): ?>
                    <img src="<?php echo e(asset("img/aide-scolaire.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '5'): ?>
                    <img src="<?php echo e(asset("img/informatique.png")); ?>" alt="" class="img-responsive image">
                    <?php elseif($post->img == '6'): ?>
                    <img src="<?php echo e(asset("img/bricolage.png")); ?>" alt="" class="img-responsive image">
                    <?php else: ?>
                    <img src="<?php echo e(asset("img/autres.png")); ?>" alt="" class="img-responsive image">
                    <?php endif; ?>
                    </a>
                </div>

                <div class="panel-header">
                        <a class="titre" href="<?php echo e(route('post.show', $post->id)); ?>"><b><?php echo e($post->title); ?></b></a>
                        <br>
                        <p class="date"><?php echo e($post->created_at); ?></p>
                        <br>
                </div>
                <div class="panel-bas">
                    <div class="row">
                    <div class="col-xs-4">
                        <p class="lieu"><b><?php echo e($post->lieu); ?></b></p>
                    </div>
                    <div class="col-xs-4">
                        <p class="prix">
                        <b><?php if($post->prix == '8'): ?>
                            <p class="prix">1€ - 10€</p>
                            <?php elseif($post->prix == '9'): ?>
                            <p class="prix">11€ - 20€</p>
                            <?php elseif($post->prix == '10'): ?>
                            <p class="prix">21€ - 30€</p>
                            <?php elseif($post->prix == '11'): ?>
                            <p class="prix">31€ - 40€</p>
                            <?php else: ?>
                            <p class="prix">41€ - 50€</a>
                            <?php endif; ?></b>
                        </p>
                    </div>
                    <div class="col-xs-4">
                        <p class="tag">
                        <b><?php if($post->img == '1'): ?>
                            #aideménagère
                            <?php elseif($post->img == '2'): ?>
                            #jardinage
                            <?php elseif($post->img == '3'): ?>
                            #babysitting
                            <?php elseif($post->img == '4'): ?>
                            #aidescolaire
                            <?php elseif($post->img == '5'): ?>
                            #informatique
                            <?php elseif($post->img == '6'): ?>
                            #bricolage
                            <?php else: ?>
                            #autre
                            <?php endif; ?></b>
                        </p>
                        </div>
                    </div>    
                    </div> 
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>