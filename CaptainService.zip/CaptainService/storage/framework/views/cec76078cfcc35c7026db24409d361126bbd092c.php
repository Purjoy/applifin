<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="panel panel-default bloc-show">

                <div class="panel-header">
                        <a class="titre" href="<?php echo e(route('post.show', $post->id)); ?>"><b><?php echo e($post->title); ?></b></a>
                        <br>
                        <p class="date"><?php echo e($post->created_at); ?></p>
                        <hr>
                </div>
                <div class="panel-body">
                    <p class="descri"><?php echo e($post->content); ?></p>
                </div>
                <div class="panel-bas">
                    <div class="row">
                    <div class="col-xs-4">
                        <span class="lieu"><b><?php echo e($post->lieu); ?></b></span>
                    </div>
                    <div class="col-xs-4">
                        <span class="prix">
                        <b><?php if($post->prix == '8'): ?>
                            <span class="prix">1€ - 10€</span>
                            <?php elseif($post->prix == '9'): ?>
                            <span class="prix">11€ - 20€</span>
                            <?php elseif($post->prix == '10'): ?>
                            <span class="prix">21€ - 30€</span>
                            <?php elseif($post->prix == '11'): ?>
                            <span class="prix">31€ - 40€</span>
                            <?php else: ?>
                            <span class="prix">41€ - 50€</span>
                            <?php endif; ?></b>
                        </span>
                    </div>
                    <div class="col-xs-4">
                        <p class="tag">
                        <b><?php if($post->img == '1'): ?>
                            #aideménagère
                            <?php elseif($post->img == '2'): ?>
                            #jardinage
                            <?php elseif($post->img == '3'): ?>
                            #babysitting
                            <?php elseif($post->img == '4'): ?>
                            #aidescolaire
                            <?php elseif($post->img == '5'): ?>
                            #informatique
                            <?php elseif($post->img == '6'): ?>
                            #bricolage
                            <?php else: ?>
                            #autre
                            <?php endif; ?></b>
                        </p>
                        </div>
                <?php if(Auth::check()
                && (Auth::user()->id == $post->user_id
                || Auth::user()->isAdmin)): ?>
                <div class="col-xs-6">
                    <a class="btn btn-default btn-modifier" href="<?php echo e(route('post.edit', $post->id)); ?>">Modifier</a>
                </div>
                <div class="col-xs-6">
                    <?php echo Form::model($post, array(
                        'route' => array('post.destroy', $post->id),
                        'method' => 'DELETE')); ?>


                    <?php echo Form::submit('Supprimer', ['class' => 'btn btn-default btn-supprimer']); ?>

                </div>
                
                <?php endif; ?>
                
                <div class="col-xs-12">
                <a class="btn btn-jsi" href="<?php echo e(route('message.creates', ['id' => $post->user_id])); ?>">Je suis interessé !</a>
                </div>
                    </div>
                    </div> 


                    <?php echo Form::close(); ?>

                </div>
                <div class="panel-footer">
                    <h2>Commentaires :</h2>
                                        <?php if(Auth::check()): ?>
                    <div class="panel-body">
                        <?php echo Form::open(array(
                            'route' => 'comment.store',
                            'method' => 'POST'
                            )); ?>

                            <?php echo Form::hidden('post_id', $post->id, ['class'=>'form-control']); ?>


                            <div class="form-group">
                                <?php echo Form::label('Comment', 'Écrire un commentaire',
                                    ['class' => 'label']); ?>

                                <?php echo Form::textarea('comment', '', 
                                    ['class' => 'form-control form-comment']); ?>

                            </div>
                        
                        <?php echo Form::submit('Publier le commentaire',
                            ['class' => 'btn btn-publier']); ?>


                        <?php echo Form::close(); ?>


                        <br>
                    </div>
                                        <?php endif; ?>


                    <?php foreach($post->comments as $comment): ?>
                    <hr>
                        <p> 
                            <div class="row">
                            <div class="col-xs-6">
                            <strong class="name-comment"><b><?php echo e($comment->user->name); ?> :</b></strong>
                            </div>
                            <div class="col-xs-6">
                            <strong class="date-comment"><?php echo e($comment->created_at); ?></strong>
                            </div>
                            </div>
                            <div class="row">
                            <div class="col-xs-12">
                            <p class="comment-comment"><?php echo e($comment->comment); ?></p>
                            </div>
                            </div>
                        </p>
                        <?php if(Auth::check()
                        && (Auth::user()->id == $comment->user_id
                        || Auth::user()->isAdmin)): ?>

                            <?php echo Form::model($comment, array(
                                'route' => array('comment.destroy', $comment->id),
                                'method' => 'DELETE')); ?>


                            <a class="btn btn-default btn-modif" href="<?php echo e(route('comment.edit', $comment->id)); ?>">Modifier</a>
                            <?php echo Form::submit('Supprimer', ['class' => 'btn btn-default btn-sup']); ?>



                            
                            
                        
                        
                        <?php endif; ?>

                        <?php echo Form::close(); ?>

                        
                        <br>

                    <?php endforeach; ?>

                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>