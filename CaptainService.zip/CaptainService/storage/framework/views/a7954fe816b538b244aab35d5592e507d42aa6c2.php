<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading" style="text-align: center;"><h2>Soumettre un projet BAP</h2></div>
                    <div class="panel-body">
                        <?php echo Form::open(array(
                            'route' => 'bap.store',
                            'method' => 'POST'
                            )); ?>

                        
                        <div class="form-group">
                            <?php echo Form::label('name', 'Nom du projet'); ?>

                            <?php echo Form::text('name', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="panel-heading" style="text-align: center;"><h4>À propos du commanditaire</h4></div>

                        <div class="form-group">
                            <?php echo Form::label('NomPrenomCHEF', 'Nom et Prénom du commanditaire'); ?>

                            <?php echo Form::text('NomPrenomCHEF', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('fonctionCHEF', 'Fonction du commanditaire'); ?>

                            <?php echo Form::text('fonctionCHEF', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('adresseCHEF', 'Adresse postale'); ?>

                            <?php echo Form::text('adresseCHEF', '', 
                                ['class' => 'form-control']); ?>

                        </div>
                            
                        <div class="form-group">
                            <?php echo Form::label('emailCHEF', 'Email'); ?>

                            <?php echo Form::text('emailCHEF', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('telCHEF', 'Téléphone'); ?>

                            <?php echo Form::text('telCHEF', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                         <div class="panel-heading" style="text-align: center;"><h4>À propos du contact</h4></div>

                        <div class="form-group">
                            <?php echo Form::label('NomPrenomCON', 'Nom et Prénom du contact'); ?>

                            <?php echo Form::text('NomPrenomCON', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('fonctionCON', 'Fonction du contact'); ?>

                            <?php echo Form::text('fonctionCON', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('adresseCON', 'Adresse postale'); ?>

                            <?php echo Form::text('adresseCON', '', 
                                ['class' => 'form-control']); ?>

                        </div>
                            
                        <div class="form-group">
                            <?php echo Form::label('emailCON', 'Email'); ?>

                            <?php echo Form::text('emailCON', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('telCON', 'Téléphone'); ?>

                            <?php echo Form::text('telCON', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="panel-heading" style="text-align: center;"><h4>Votre fiche d'identité</h4></div>

                        <div class="form-group">
                            <?php echo Form::label('social', 'Raison social, activité ...'); ?>

                            <?php echo Form::textarea('social', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('type', 'Type de demande'); ?> <br>
                            <?php echo Form::label('type', 'Site Internet'); ?>

                            <?php echo Form::radio('type', 'site'); ?>

                            <?php echo Form::label('type', '3D'); ?>

                            <?php echo Form::radio('type', '3D'); ?>

                            <?php echo Form::label('type', 'Animation 2D'); ?>

                            <?php echo Form::radio('type', '2D'); ?>

                            <?php echo Form::label('type', 'Installation Multimédia'); ?>

                            <?php echo Form::radio('type', 'multimedia'); ?>

                            <?php echo Form::label('type', 'Jeux Vidéo'); ?>

                            <?php echo Form::radio('type', 'JV'); ?>

                            <?php echo Form::label('type', 'DVD'); ?>

                            <?php echo Form::radio('type', 'DVD'); ?>

                            <?php echo Form::label('type', 'Print'); ?>

                            <?php echo Form::radio('type', 'print'); ?>

                            <?php echo Form::label('type', 'CD ROM'); ?>

                            <?php echo Form::radio('type', 'CD'); ?>

                            <?php echo Form::label('type', 'Événement'); ?>

                            <?php echo Form::radio('type', 'evenement'); ?>

                            <?php echo Form::label('type', 'Autre'); ?>

                            <?php echo Form::radio('type', 'autre'); ?>

                        </div>
                        
                        <div class="form-group">
                            <?php echo Form::label('raison', 'Raison de la demande'); ?>

                            <?php echo Form::textarea('raison', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('contexte', 'Contexte de la demande'); ?>

                            <?php echo Form::textarea('contexte', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('objectif', 'Objectifs de la demande'); ?>

                            <?php echo Form::textarea('objectif', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('contraintes', 'Contraintes particulières et informations complémentaires'); ?>

                            <?php echo Form::textarea('contraintes', '', 
                                ['class' => 'form-control']); ?>

                        </div>

                </div>

            <div class="panel-footer">
                        <?php echo Form::submit('Envoyer',
                            ['class' => 'btn btn-primary']); ?>


                        <?php echo Form::close(); ?>

                <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>