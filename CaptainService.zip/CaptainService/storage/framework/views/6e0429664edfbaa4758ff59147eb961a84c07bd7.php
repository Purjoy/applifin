<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="panel panel-default">
                <div class="panel-heading">Envoyer un message</div>

                <?php echo Form::open(array(
                            'route' => 'message.store'
                            )); ?>

                    <div class="panel-body">

                            <div class="form-group">
                                <?php echo Form::textarea('message', '',
                                    ['class' => 'form-control',
                                    ]); ?>


                                <?php echo Form::hidden('destinataire', $user->id); ?>

                            </div>


                    </div>
                    <div class="panel-footer">
                        <?php echo Form::submit('Publier l\'article',
                            ['class' => 'btn btn-primary']); ?>


                    </div>

                <?php echo Form::close(); ?>

                <a class="btn btn-default" href="<?php echo e(route('post.index')); ?>">Retour aux articles</a>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>