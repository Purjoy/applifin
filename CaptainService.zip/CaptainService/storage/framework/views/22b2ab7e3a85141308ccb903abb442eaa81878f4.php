 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
        <?php echo $__env->make('errors.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php foreach($list as $bap): ?>
                <div class="col-md-10 col-md-offset-1">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a href="<?php echo e(route('bap.show', $bap->id)); ?>"><?php echo e($bap->name); ?></a> | Soumis le : <?php echo e($bap->created_at); ?>

                        </div>

                        <div class="panel-body">
                            <p><?php echo e($bap->type); ?> pour <?php echo e($bap->NomPrenomCHEF); ?> <br>
                            <?php if($bap->accepted == 1): ?> 
                                Statut: Accepté
                            <?php elseif($bap->accepted == 2): ?>
                                Statut: Refusé
                            <?php elseif($bap->accepted == 0): ?>
                                Statut: En attente
                            <?php endif; ?>
                            </p>
                        </div>
                        <div class="panel-footer">

                            <?php echo Form::model($bap,
                            array(
                            'route' => array('bap.update', $bap->id),
                            'method' => 'PUT'
                            )); ?>

                            <?php echo Form::select('accepted', [
                                   '0' => 'En attente',
                                   '1' => 'Accepter',
                                   '2' => 'Refuser']
                                ); ?>

                            <?php echo Form::submit('Valider',
                                    ['class' => 'btn btn-primary']); ?>


                            <?php echo Form::close(); ?>

                            
                            <br>
        
                            <?php echo Form::model($bap, array(
                                'route' => array('bap.destroy', $bap->id),
                                'method' => 'DELETE')); ?>


                            <?php echo Form::submit('Supprimer', ['class' => 'btn btn-default']); ?>


                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php echo $list->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>