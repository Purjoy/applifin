@extends('layouts.app')

@section('content')
    <div class="container">
                      <h1> bonjour </h1>
    </div>
@endsection