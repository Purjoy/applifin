@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    @include('errors.message')
            <div class="panel panel-default">
                <div class="panel-heading">Envoyer un message</div>

                {!! Form::open(array(
                            'route' => 'message.store'
                            ))
                        !!}
                    <div class="panel-body">

                            <div class="form-group">
                                {!! Form::textarea('message', '',
                                    ['class' => 'form-control',
                                    ])
                                !!}

                                {!! Form::hidden('destinataire', $user->id)!!}
                            </div>


                    </div>
                    <div class="panel-footer">
                        {!! Form::submit('Publier l\'article',
                            ['class' => 'btn btn-primary'])
                        !!}

                    </div>

                {!! Form::close() !!}
                <a class="btn btn-default" href="{{ route('post.index') }}">Retour aux articles</a>
                </div>
            </div>
    </div>
</div>
@endsection