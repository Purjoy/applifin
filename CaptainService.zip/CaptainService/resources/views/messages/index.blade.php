@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row bloc-index">
        @include('errors.message')

        @foreach($list as $post)
            <div class="well">
                {{ $post->message  }}
            </div>


    @endforeach
</div>
</div>
@endsection