@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    @include('errors.message')
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Ajouter un article</div>
                    <div class="panel-body">
                        {!! Form::open(array(
                            'route' => 'post.store',
                            'method' => 'POST'
                            ))
                        !!}
                            <div class="form-group">
                                {!! Form::label('title', 'Titre') !!}
                                {!! Form::text('title', '', 
                                    ['class' => 'form-control',
                                    ]) 
                                !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('img', 'Type de service : ') !!}
                                {!! Form::select('img', array('1' => 'Aide ménagère', '2' => 'Jardinnage', '3' => 'Babysitting', '4' => 'Aide scolaire', '5' => 'Informatique', '6' => 'Bricolage', '7' => 'Autre'),
                                    ['class' => 'form-control'
                                    ]);
                                !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('content', 'Description') !!}
                                {!! Form::textarea('content', '', 
                                    ['class' => 'form-control',
                                    'placeholder' => 'Quelle est votre demande ?'
                                    ]) 
                                !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('prix', 'Tranche de prix : ') !!}
                                {!! Form::select('prix', array('8' => '1€ - 10€', '9' => '11€ - 20€', '10' => '21€ - 30€', '11' => '31€ - 40€', '12' => '41€ - 50€'),
                                    ['class' => 'form-control'
                                    ]);
                                !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('lieu', 'Ville') !!}
                                {!! Form::text('lieu', '', 
                                    ['class' => 'form-control',
                                    'placeholder' => ''
                                    ]) 
                                !!}
                            </div>
                        
                    </div>
                    <div class="panel-footer">
                        {!! Form::submit('Publier l\'article',
                            ['class' => 'btn btn-primary'])
                        !!}

                        {!! Form::close() !!}
                        <a class="btn btn-default" href="{{ route('post.index') }}">Retour aux articles</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection