@extends('layouts.app')

@section('content')

	La page que vous cherchez n'existe pas !

@endsection